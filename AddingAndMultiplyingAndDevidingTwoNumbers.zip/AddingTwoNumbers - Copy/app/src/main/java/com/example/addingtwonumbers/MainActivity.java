package com.example.addingtwonumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText num1;
    private EditText num2;
    private Button add;
    private Button multiply;
    private Button div;
    private TextView result;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = (EditText)findViewById(R.id.etNum1);
        num2 = (EditText)findViewById(R.id.etNum2);
        add =  (Button)findViewById(R.id.btn);
        multiply =  (Button)findViewById(R.id.btn2);
        div =  (Button)findViewById(R.id.btn3);
        result = (TextView)findViewById(R.id.tvAnswer);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Number1 = Integer.parseInt( num1.getText().toString());
                int Number2 = Integer.parseInt( num2.getText().toString());
                int sum = Number1 + Number2;
                result.setText("Answer: " + String.valueOf(sum));
                //Toast
                Toast.makeText(MainActivity.this ,"Calculating..." , Toast.LENGTH_SHORT).show();
            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Number3 = Integer.parseInt( num1.getText().toString());
                int Number4 = Integer.parseInt( num2.getText().toString());
                int sum2 = Number3 * Number4;
                result.setText("Answer: " + String.valueOf(sum2));
                //Toast
                Toast.makeText(MainActivity.this ,"Calculating..." , Toast.LENGTH_SHORT).show();
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Number5 = Integer.parseInt( num1.getText().toString());
                int Number6 = Integer.parseInt( num2.getText().toString());
                int sum3 = Number5 / Number6;
                result.setText("Answer: " + String.valueOf(sum3));
                //Toast
                Toast.makeText(MainActivity.this ,"Calculating..." , Toast.LENGTH_SHORT).show();
            }
        });
    }
}